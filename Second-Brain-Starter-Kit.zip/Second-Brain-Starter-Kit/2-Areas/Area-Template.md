---
title: "Area Template"
created: 2026-02-26
para-type: area
status: active
tags: [area, template]
links: ["[[Areas Hub]]"]
---

## Scope

Describe the ongoing responsibility this Area represents.

## Standards

- What does "healthy" look like for this Area?
- What should you review periodically?

