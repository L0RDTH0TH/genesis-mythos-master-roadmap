---
title: Areas Hub
created: 2026-02-26
para-type: Resource
status: active
tags: [hub, areas]
links: []
---

# Areas Hub

Overview of ongoing responsibilities (Areas).

You can add Dataview queries here if you use the Dataview plugin.

