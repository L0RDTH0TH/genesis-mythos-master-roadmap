---
title: Welcome to Second-Brain Starter Kit
created: 2026-02-26
para-type: Resource
status: active
tags: [onboarding, starter-kit]
---

# Welcome to the Second-Brain Starter Kit

This vault is a **minimal, automation-ready Second Brain**:

- PARA folders (`1-Projects/`, `2-Areas/`, `3-Resources/`, `4-Archives/`).
- `Ingest/` for all new captures.
- Safety layers (`Backups/Per-Change/`, `Backups/Batch/`, external `BACKUP_DIR`).
- Cursor + MCP pipelines for **Ingest, Organize, Distill, Express, Archive**.

## Quick Start

1. Open this vault in **Obsidian**.
2. Follow `0-Onboarding/Install-Steps.md` to:
   - Install required plugins.
   - Configure `~/.cursor/mcp.json` with this vault path and backup/snapshot dirs.
   - Start the MCP server.
3. Open this vault in **Cursor**.
4. Drop a test note into `Ingest/` or use `Ingest/Test-Capture-1.md` once created.
5. In Cursor, run **`INGEST MODE – process captures`** (or **"Process Ingest"**).

If everything is configured, the pipelines will:

- Backup the note.
- Classify it into PARA.
- Enrich frontmatter.
- Lightly distill and extract tasks.
- Propose or perform a move out of `Ingest/`.

## Trigger phrases (for later)

- **Ingest**: `INGEST MODE – process captures`, `Process Ingest`, `run ingests`.
- **Organize**: `ORGANIZE MODE – safe batch autopilot`, `re-organize this note`.
- **Distill**: `DISTILL MODE – safe batch autopilot`, `distill this note`.
- **Express**: `EXPRESS MODE – safe batch autopilot`, `express this note`.
- **Archive**: `ARCHIVE MODE – safe batch autopilot`, `archive this note`.
- **Onboarding cleanup**: When you are done with onboarding, say **"Onboarding complete"** in Cursor to archive `0-Onboarding/**` into `4-Archives/Onboarding-Complete/`.

## Next steps

- Read `0-Onboarding/Install-Steps.md` to finish setup.
- Use `0-Onboarding/Basic-Examples.md` to create your first Project/Area/Resource notes.
- Check `3-Resources/Resources-Hub.md` for system docs and logs.

