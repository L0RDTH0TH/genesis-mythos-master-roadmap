---
title: Troubleshooting
created: 2026-02-26
para-type: Resource
status: active
tags: [onboarding, troubleshooting]
---

# Troubleshooting

Common issues when getting the starter kit running.

## MCP not connected

**Symptoms:**

- Cursor errors mentioning missing MCP tools (e.g. `obsidian_read_note` not found).

**Checks:**

- MCP server process is running in a terminal.
- `~/.cursor/mcp.json` points `VAULT_PATH` to this vault and has valid paths for `BACKUP_DIR`, `SNAPSHOT_DIR`, `BATCH_SNAPSHOT_DIR`.

See: `3-Resources/Config-Defaults.md`, `3-Resources/Second-Brain-Config.md`.

## Cursor rules not loading

**Symptoms:**

- Pipelines don’t react to phrases like `INGEST MODE` or `ORGANIZE MODE`.

**Checks:**

- This vault is opened as a workspace in Cursor.
- `.cursor/` folder exists at the vault root (you should see `.cursor/rules` and `.cursor/skills`).

## Backup or snapshot path problems

**Symptoms:**

- Errors mentioning snapshot directories or backup paths.

**Checks:**

- `Backups/Per-Change/` and `Backups/Batch/` exist in this vault.
- `BACKUP_DIR` in `~/.cursor/mcp.json` is writable and outside the vault.

See: `3-Resources/enhanced-snapshots.md`, `3-Resources/Backup-Log.md`.

## Logs and errors

If something fails, look at:

- `3-Resources/Ingest-Log.md`
- `3-Resources/Archive-Log.md`
- `3-Resources/Distill-Log.md`
- `3-Resources/Express-Log.md`
- `3-Resources/Organize-Log.md`
- `3-Resources/Backup-Log.md`
- `3-Resources/Errors.md`

Entries with `#review-needed` indicate items that may need manual attention.

