---
title: Install & Setup Steps
created: 2026-02-26
para-type: Resource
status: active
tags: [onboarding, setup]
---

# Install & Setup Steps

Follow these steps to get the starter kit working with Obsidian, Cursor, and the Obsidian MCP server.

## 1. Install required Obsidian plugins

Install (or enable) these community plugins:

- **Dataview**
- **Highlightr**
- **Obsidian Local REST API**
- **Watcher**

Optional but present in the `.obsidian` config:

- Templater, Tasks, QuickAdd, Excalidraw, OCR-related plugins.

**Verify:**

- In Obsidian → Settings → Community plugins, these plugins are enabled.

## 2. Confirm Obsidian configuration

Key expectations:

- Attachments default to `99 Attachments/`.
- Graph, appearance, and workspace settings are already reasonable for this kit.

**Verify:**

- Opening this vault shows the **Files** pane on the left and this note or `Welcome-to-Second-Brain.md` in the main pane.

## 3. Configure MCP (`~/.cursor/mcp.json`)

Edit `~/.cursor/mcp.json` so the `obsidian-para-zettel-autopilot` server knows about this vault. A minimal example (adapt to your actual file) looks like:

```json
{
  "mcpServers": {
    "obsidian-para-zettel-autopilot": {
      "command": "node",
      "args": ["path/to/server.js"],
      "env": {
        "VAULT_PATH": "/absolute/path/to/Second-Brain-Starter-Kit",
        "BACKUP_DIR": "/absolute/path/to/Second-Brain-Starter-Kit-Backups",
        "SNAPSHOT_DIR": "/absolute/path/to/Second-Brain-Starter-Kit/Backups/Per-Change",
        "BATCH_SNAPSHOT_DIR": "/absolute/path/to/Second-Brain-Starter-Kit/Backups/Batch",
        "MAX_BACKUP_AGE_MINUTES": "1440"
      }
    }
  }
}
```

Adjust:

- `VAULT_PATH` to this vault’s absolute path.
- `BACKUP_DIR` to a sibling folder outside the vault.
- `SNAPSHOT_DIR` and `BATCH_SNAPSHOT_DIR` to the `Backups/` subfolders inside this vault.

**Verify:**

- Cursor shows the MCP server as connected (no obvious connection errors).

## 4. Start the MCP server

From a terminal, start the Obsidian MCP server for this vault (exact command depends on your setup):

```bash
cd /path/to/your/mcp-server
node server.js
```

Keep this process running while using Cursor with this vault.

**Verify:**

- The MCP server logs show successful startup.
- Cursor can call basic tools like `obsidian_read_note` without error.

## 5. Open the vault in Cursor

- In Cursor, open the folder containing `Second-Brain-Starter-Kit/` as a workspace.
- Ensure `.cursor/` is visible and rules are loaded.

**Verify:**

- Asking Cursor about `Config-Defaults.md` or `Second-Brain-Config.md` returns the note contents.

## 6. Run a health check

With Obsidian open on this vault and the MCP server running:

1. In Cursor, ask to **run the MCP `health_check` tool** via the obsidian MCP server.
2. Log the result by appending a short entry to a note like `3-Resources/MCP-Health-YYYY-MM.md` (you can create this manually).

**Verify:**

- `health_check` reports an OK status.
- You have a log entry noting that the MCP is healthy for this vault.

## 7. First ingest test (optional but recommended)

Once everything above is configured:

1. Ensure there is at least one test note under `Ingest/` (e.g. `Test-Capture-1.md`).
2. In Cursor, run **`INGEST MODE – process captures`**.
3. Inspect:
   - `3-Resources/Ingest-Log.md` for log entries.
   - `3-Resources/Backup-Log.md` for backup/snapshot entries.

You can find more detailed pipeline documentation in:

- `3-Resources/Cursor-Skill-Pipelines-Reference.md`
- `3-Resources/Second-Brain-Automations-Setup-Report.md`

