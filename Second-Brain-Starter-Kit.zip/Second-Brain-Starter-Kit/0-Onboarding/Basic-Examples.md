---
title: Basic Examples
created: 2026-02-26
para-type: Resource
status: active
tags: [onboarding, examples]
---

# Basic Examples

Use these snippets to create your first Project, Area, and Resource notes.

After creating them, you can run **ORGANIZE MODE** or **DISTILL MODE** in Cursor to see the pipelines in action.

## Project example

Create a new note under `1-Projects/` with content like:

```markdown
---
title: "Example Project"
created: 2026-02-26
para-type: project
status: active
project-id: example-project
highlight_key: default
tags: [project, example]
links: ["[[Projects Hub]]"]
---

## Goal

- Ship a tiny demo project using this starter kit.

## Next actions

- [ ] Configure MCP for this vault.
- [ ] Run INGEST MODE on a test capture.
```

## Area example

Create a note under `2-Areas/`:

```markdown
---
title: "Example Area"
created: 2026-02-26
para-type: area
status: active
tags: [area, example]
links: ["[[Areas Hub]]"]
---

## Scope

Ongoing responsibility such as "Personal Knowledge Management" or "Career Development".
```

## Resource example

Create a note under `3-Resources/`:

```markdown
---
title: "Example Resource"
created: 2026-02-26
para-type: resource
status: active
tags: [resource, example]
links: ["[[Resources Hub]]"]
---

## Notes

Short reference note to test distill and express pipelines.
```

Once you have one or two of these notes, try:

- `ORGANIZE MODE – safe batch autopilot on 1-Projects/`  
- `DISTILL MODE – safe batch autopilot` on a single project/resource note.

