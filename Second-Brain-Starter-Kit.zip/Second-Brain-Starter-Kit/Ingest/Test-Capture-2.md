---
title: "Test Capture 2"
created: 2026-02-26
tags: [ingest, test]
---

Another short test capture with slightly different content to exercise classification variety.

You can run **INGEST MODE – process captures** with both `Test-Capture-1.md` and this note present to see how the pipeline handles multiple captures.

