---
title: "Test Capture 1"
created: 2026-02-26
tags: [ingest, test]
---

This is a small, neutral test capture.

Use it to verify that **INGEST MODE – process captures** runs end‑to‑end:

- Backup is created.
- The note is classified into PARA.
- Frontmatter is enriched.
- A path is proposed or executed out of `Ingest/`.

