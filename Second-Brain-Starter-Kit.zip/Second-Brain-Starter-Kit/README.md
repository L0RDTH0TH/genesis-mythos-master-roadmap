Second-Brain Starter Kit Vault
================================

This folder is a **clean, distributable Obsidian vault** designed as a starter kit for an autonomous PARA-based Second Brain.

Key characteristics:

- **PARA structure**: `1-Projects/`, `2-Areas/`, `3-Resources/`, `4-Archives/`.
- **Capture flow**: `Ingest/` for all new notes, plus `0-Onboarding/` for first-run guidance.
- **Safety**: `Backups/Per-Change/`, `Backups/Batch/`, and `Versions/` for snapshots and versioning.
- **Automation-ready**: A `.cursor/` folder (rules + skills) and `.obsidian/` configuration tuned for Dataview, Highlightr, Local REST API, and Watcher.

To use this kit:

1. Copy or unzip `Second-Brain-Starter-Kit/` to your preferred location.
2. Open it as a vault in Obsidian.
3. Follow `0-Onboarding/Welcome-to-Second-Brain.md` and `0-Onboarding/Install-Steps.md` to finish setup.

