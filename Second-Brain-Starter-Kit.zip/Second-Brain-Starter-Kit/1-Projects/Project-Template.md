---
title: "Project Template"
created: 2026-02-26
para-type: project
status: active
project-id: example-project
highlight_key: default
tags: [project, template]
links: ["[[Projects Hub]]"]
---

## Goal

Describe the outcome you want for this project.

## Scope

- What is in scope?
- What is explicitly out of scope?

## Next actions

- [ ] First concrete step
- [ ] Second concrete step

