---
title: Archive Log
created: 2026-02-26
para-type: Resource
status: active
tags: [log, archive, pipelines]
---

# Archive Log

Pipeline log for **autonomous-archive** and **onboarding-archive** runs.

Entries record archive decisions, confidence, target paths under `4-Archives/`, backups, snapshots, and any `#review-needed` flags.

