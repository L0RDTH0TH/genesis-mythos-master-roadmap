---
watcher-protected: true
title: Watched file
created: 2026-02-26
para-type: Resource
status: active
tags: [watcher, automation]
---

# Watched file

This note is used by the Obsidian Watcher plugin. Pipelines treat it as `watcher-protected: true` and must not move or delete it.

