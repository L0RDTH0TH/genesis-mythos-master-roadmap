---
title: Second-Brain Automations Setup — Cursor + Obsidian (Starter Kit)
created: 2026-02-26
tags: [pkm, automation, cursor, obsidian, pipelines, skills]
para-type: resource
status: active
links: ["[[Cursor-Skill-Pipelines-Reference.md]]"]
---

### Purpose of this report

- **Goal**: Summarize how automations are configured in this starter vault: pipelines, skills, triggers, confidence gates, logging, and safety rails.
- **Scope**: Cursor-side skills, `.cursor/rules/**` pipeline rules, Obsidian MCP integration, snapshot/backup strategy, and how everything interacts with the PARA structure.

### 1. High-level architecture

- **Vault model**:
  - **PARA** roots: `1-Projects/`, `2-Areas/`, `3-Resources/`, `4-Archives/`.
  - **Ingest/** as the **only** entry point for new/unknown files (including non‑markdown).
- **Automation stack**:
  - **Cursor rules** (`.cursor/rules/always/**`, `.cursor/rules/context/**`) define:
    - Always-on constraints (backups, snapshots, no shell file ops, ingest bootstrap, MCP safety).
    - Context rules per pipeline (distill, archive, express, organize, ingest-processing, onboarding-archive, etc.).
  - **Cursor skills** (`.cursor/skills/<skill-name>/SKILL.md`) provide reusable operations plugged into pipelines:
    - E.g. `frontmatter-enrich`, `subfolder-organize`, `distill-highlight-color`, `version-snapshot`, etc.
  - **Obsidian MCP server** handles:
    - Note-level ops: `obsidian_read_note`, `obsidian_update_note`, `obsidian_move_note`, `obsidian_rename_note`, `obsidian_list_notes`, `obsidian_create_backup`, `obsidian_log_action`, `obsidian_ensure_structure`, plus snapshot/version helpers via skills.
- **Pipelines** (see `Cursor-Skill-Pipelines-Reference.md`):
  - **full-autonomous-ingest** — capture → classify → organize → light distill → tasks → hub append → move.
  - **autonomous-distill** — periodic deepening of existing notes.
  - **autonomous-archive** — move completed/inactive items into `4-Archives/`.
  - **autonomous-express** — generate outlines/related content/CTAs from distilled notes.
  - **autonomous-organize** — re‑organize existing notes inside active PARA folders.
  - **onboarding-archive** — one-time archive flow for `0-Onboarding/**` when the user says **"Onboarding complete"**.

### 2. Trigger phrases → pipelines

- **full-autonomous-ingest**
  - **Triggers**: `"Ingest"`, `"process Ingest"`, `"run ingests"`, or any explicit reference to `Ingest/` / unprocessed captures.
  - **Rules**: `always-ingest-bootstrap` (always), `ingest-processing.mdc` (Ingest‑specific), `para-zettel-autopilot.mdc`.
- **autonomous-distill**
  - **Triggers**: `"DISTILL MODE – safe batch autopilot"`, `"distill this note"`, `"distill current file"`, `"refine this note"`, `"autonomous distill on folder X"`.
  - **Rule**: `.cursor/rules/context/auto-distill.mdc`.
- **autonomous-archive**
  - **Triggers**: `"ARCHIVE MODE – safe batch autopilot"`, `"archive this note"`, `"send to Archives"`, `"move completed to 4-Archives"`.
  - **Rule**: `.cursor/rules/context/auto-archive.mdc`.
- **autonomous-express**
  - **Triggers**: `"EXPRESS MODE – safe batch autopilot"`, `"express this note"`, `"generate outline"`, `"create publishable summary"`, `"turn this into an outline/post"`.
  - **Rule**: `.cursor/rules/context/auto-express.mdc`.
- **autonomous-organize**
  - **Triggers**: `"ORGANIZE MODE – safe batch autopilot (on [folder])"`, `"re-organize this note"`, `"re-organize Projects and Resources"`, `"classify and move"`, `"put this note in the right folder"`.
  - **Rule**: `.cursor/rules/context/auto-organize.mdc`.
- **onboarding-archive**
  - **Trigger**: `"Onboarding complete"` (explicit phrase).
  - **Rule**: `.cursor/rules/context/onboarding-archive.mdc` — archives `0-Onboarding/**` to `4-Archives/Onboarding-Complete/`.

### 3. Safety model (backups, snapshots, confidence)

- **Backups**:
  - `obsidian_create_backup` or `obsidian_ensure_backup` must succeed before destructive steps (moves, renames, overwrites).
  - Backup root (`BACKUP_DIR`) is configured in `~/.cursor/mcp.json` and should be outside the vault (e.g. `Second-Brain-Starter-Kit-Backups/`).
- **Snapshots**:
  - Per-change snapshots live under `Backups/Per-Change/`.
  - Batch snapshots live under `Backups/Batch/`.
  - The `obsidian-snapshot` skill is called before structural changes per pipeline (see `Cursor-Skill-Pipelines-Reference.md`).
- **Confidence bands** (from `confidence-loops.mdc`):
  - **High** (≥85%): destructive actions allowed if snapshot succeeds.
  - **Mid** (72–84%): one non-destructive refinement loop; destructive actions only if `post_loop_conf ≥85%` and snapshot succeeds.
  - **Low** (<72%): no destructive actions; propose-only and log with `#review-needed`.

### 4. Logs and observability

The following log notes are pre-created in this starter kit:

- `3-Resources/Ingest-Log.md`
- `3-Resources/Archive-Log.md`
- `3-Resources/Distill-Log.md`
- `3-Resources/Express-Log.md`
- `3-Resources/Organize-Log.md`
- `3-Resources/Backup-Log.md`
- `3-Resources/Errors.md`

Pipelines append one line per processed note using a standard format (see `Cursor-Skill-Pipelines-Reference.md`), including:

- Timestamp, pipeline, note path.
- Confidence and actions taken/skipped.
- Backup/snapshot/version paths when relevant.
- `#review-needed` when manual review is required.

### 5. How to adapt this setup

- Adjust confidence thresholds, archive age, or backup age in `3-Resources/Config-Defaults.md`.
- Change hub names and highlight defaults in `3-Resources/Second-Brain-Config.md`.
- Extend or modify pipelines in `Cursor-Skill-Pipelines-Reference.md` and the `.cursor/rules/context/*.mdc` files.
- Use `3-Resources/MCP-Tools-Reference.md` as a quick reference for available MCP tools and parameters.

