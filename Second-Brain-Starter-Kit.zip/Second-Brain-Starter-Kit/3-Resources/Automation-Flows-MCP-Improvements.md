---
title: Automation Flows — MCP Server Improvement Proposals (Starter Kit)
created: 2026-02-26
tags: [pkm, automation, cursor, obsidian, mcp, pipelines, improvement]
para-type: resource
status: active
links:
  - "[[Second-Brain-Automations-Setup-Report.md]]"
  - "[[Cursor-Skill-Pipelines-Reference.md]]"
---

### Purpose

This note summarizes how additional MCP tools (from the `obsidian-para-zettel-autopilot` server) can be used with the starter kit pipelines. It is a shortened version of the improvement report from the source vault, focused on ideas you can adopt later rather than behaviors that are already wired into this kit.

Example tools to explore:

- `obsidian_ensure_backup` for smarter backup checks before long batches.
- `obsidian_subfolder_organize` for multiple path candidates in ingest/organize/archive mid-band loops.
- `calibrate_confidence`, `verify_classification`, `propose_alternative_paths` for mid-band and failure fallbacks.
- `obsidian_suggest_connections` for richer related-content in EXPRESS MODE.
- `obsidian_garden_review` and `obsidian_curate_cluster` for garden review and cluster curation flows.

The starter kit pipelines are intentionally conservative; refer back to your main vault’s `Automation-Flows-MCP-Improvements.md` if you want to gradually adopt these advanced flows.

