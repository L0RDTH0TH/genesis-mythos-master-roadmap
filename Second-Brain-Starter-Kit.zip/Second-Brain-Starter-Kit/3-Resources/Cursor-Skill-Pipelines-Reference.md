---
title: Cursor Skill Pipelines Reference
created: 2026-02-26
tags: [pkm, cursor, second-brain, pipelines, skills]
para-type: Resource
status: active
links: ["[[Resources Hub]]"]
---

# Cursor Skill Pipelines Reference

**Single Pipelines-and-Rules-Reference** for the autonomous skill pipelines (full-autonomous-ingest, autonomous-distill, autonomous-archive, autonomous-express, autonomous-organize), trigger → rule mapping, and skills. Skills live in `.cursor/skills/<skill-name>/`; always-applied rules and context-specific rules define triggers and safety (backup-first, no shell vault ops).

The contents of this note mirror the reference used in the main `Second-Brain` vault, adapted so that all links point to files that exist in this starter kit (e.g. `Second-Brain-Config.md`, `Highlightr-Color-Key.md`, log notes).

For full details, see the copy from your source vault or the summary sections in this starter kit:

- Triggers and rules: how `INGEST MODE`, `ORGANIZE MODE`, `DISTILL MODE`, `EXPRESS MODE`, `ARCHIVE MODE`, and `"Onboarding complete"` map to pipelines.
- Confidence bands and loops: low (<72%), mid (72–84), high (≥85%), and how mid-band refinement loops work.
- Snapshot triggers: when to call the `obsidian-snapshot` skill (per-change and batch) across all pipelines.
- Skill catalog: which SKILL.md files are used in each pipeline, and where they live under `.cursor/skills/`.

This reference is intentionally concise in the starter kit. For more narrative explanations, also read:

- `3-Resources/Second-Brain-Automations-Setup-Report.md`
- `3-Resources/Automation-Flows-MCP-Improvements.md`
- `3-Resources/Config-Defaults.md`

