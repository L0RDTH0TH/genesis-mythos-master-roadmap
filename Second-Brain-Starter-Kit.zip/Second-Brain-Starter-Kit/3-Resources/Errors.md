---
title: Pipeline and Workflow Errors
created: 2026-02-26
para-type: Resource
status: active
tags: [errors, pipelines, cursor, obsidian, review]
---

# Pipeline and Workflow Errors

Central log for **traced errors** from ingest, distill, archive, express, organize, and supporting workflows.

Each new error should be appended as:

### YYYY-MM-DD HH:MM — Short Title

| Field | Value |
|-------|-------|
| pipeline | autonomous-ingest / autonomous-distill / ... |
| severity | low / medium / high |
| approval | pending / approved |
| timestamp | 2026-02-26T00:00:00Z |
| error_type | mcp-api / io-failure / classification-empty / ... |

#### Trace

- Timestamp, pipeline, stage, affected note path(s).
- Raw error message or stack (sanitized).

#### Summary

- **Root cause:** …
- **Impact:** …
- **Suggested fixes:** …
- **Recovery:** …

