---
title: Backup & Snapshot Log
created: 2026-02-26
para-type: Resource
status: active
tags: [log, backups, snapshots]
---

# Backup & Snapshot Log

Central log for **backups** (`obsidian_create_backup`, `obsidian_ensure_backup`) and **snapshots** (`obsidian-snapshot`, `version-snapshot`).

Each pipeline appends entries here when creating backups or snapshots, including paths, confidence, and any `#review-needed` flags.

