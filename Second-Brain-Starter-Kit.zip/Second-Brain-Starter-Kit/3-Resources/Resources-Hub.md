---
title: Resources Hub
created: 2026-02-26
para-type: Resource
status: active
tags: [hub, resources]
links: []
---

# Resources Hub

Central hub for reference notes in `3-Resources/` plus system docs for the starter kit.

- **Config**: `Second-Brain-Config.md`, `Config-Defaults.md`
- **Pipelines**: `Cursor-Skill-Pipelines-Reference.md`, `Second-Brain-Automations-Setup-Report.md`
- **MCP**: `MCP-Tools-Reference.md`, `Automation-Flows-MCP-Improvements.md`
- **Safety**: `enhanced-snapshots.md`, `Backup-Log.md`, `Errors.md`

You can add Dataview blocks here if you use the Dataview plugin, for example:

```dataview
TABLE file.name AS "Resource", status
FROM "3-Resources"
WHERE file.name != "Resources-Hub.md"
SORT file.name
```

