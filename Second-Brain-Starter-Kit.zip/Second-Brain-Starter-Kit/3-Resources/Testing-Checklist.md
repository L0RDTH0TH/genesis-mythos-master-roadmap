---
title: Starter Kit Testing Checklist
created: 2026-02-26
para-type: Resource
status: active
tags: [testing, pipelines]
---

# Starter Kit Testing Checklist

Use this checklist to validate that the main pipelines are wired correctly. You can run these tests manually after completing `Install-Steps.md`.

## 1. Ingest pipeline

- [ ] Ensure `Ingest/Test-Capture-1.md` and `Ingest/Test-Capture-2.md` exist.
- [ ] In Cursor, run **`INGEST MODE – process captures`**.
- [ ] Confirm:
  - [ ] `3-Resources/Ingest-Log.md` has new entries for both test captures.
  - [ ] `3-Resources/Backup-Log.md` shows backups for each note.
  - [ ] Notes are either proposed for move or moved out of `Ingest/` according to confidence rules.

## 2. Organize pipeline

- [ ] Create a copy of `1-Projects/Project-Template.md` as a real project.
- [ ] In Cursor, run **`ORGANIZE MODE – safe batch autopilot on 1-Projects/`**.
- [ ] Confirm:
  - [ ] `3-Resources/Organize-Log.md` shows entries for the project note.
  - [ ] Any moves are preceded by dry_run notes in the log (or no moves when confidence is low).

## 3. Distill pipeline

- [ ] Open a project or resource note with some body text.
- [ ] In Cursor, run **`DISTILL MODE – safe batch autopilot`** on that note.
- [ ] Confirm:
  - [ ] TL;DR exists and is wrapped in a `[!summary]` callout.
  - [ ] Highlights follow the color rules in `Highlightr-Color-Key.md`.
  - [ ] `3-Resources/Distill-Log.md` and `3-Resources/Backup-Log.md` contain entries with snapshot info.

## 4. Express pipeline

- [ ] Choose a distilled note from step 3.
- [ ] In Cursor, run **`EXPRESS MODE – safe batch autopilot`**.
- [ ] Confirm:
  - [ ] A small outline or expressive block is appended.
  - [ ] A CTA callout (e.g. Share/Publish?) appears at the end.
  - [ ] `3-Resources/Express-Log.md` and `3-Resources/Backup-Log.md` record version-snapshot and per-change snapshots.

## 5. Archive pipeline

- [ ] Create or pick a note that you can safely archive (e.g. a test project or area marked complete).
- [ ] In Cursor, run **`ARCHIVE MODE – safe batch autopilot`** targeting that note/folder.
- [ ] Confirm:
  - [ ] The note moves under `4-Archives/…` if archive checks pass.
  - [ ] `3-Resources/Archive-Log.md` and `3-Resources/Backup-Log.md` show the move with snapshot info.

## 6. Onboarding archive flow

- [ ] Once comfortable with the starter kit, in Cursor type **"Onboarding complete"**.
- [ ] Confirm:
  - [ ] Files under `0-Onboarding/` are moved into `4-Archives/Onboarding-Complete/`.
  - [ ] `3-Resources/Archive-Log.md` logs the onboarding archive sweep.

