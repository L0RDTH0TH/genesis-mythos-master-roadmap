---
title: Config Defaults (Starter Kit)
created: 2026-02-26
tags: [config, pipelines, safety]
para-type: Resource
status: active
links: [[Resources Hub]]
---

# Config Defaults — Starter Kit

Editable defaults for the starter kit. Change values here if you want to tune behavior **without editing rules or skills**.

## Confidence bands

- **High**: `conf >= 85` → destructive actions allowed **only** after per-change snapshot.
- **Mid**: `72 <= conf <= 84` → one non-destructive refinement loop per note per pipeline run.
- **Low**: `conf < 72` → no destructive actions; propose-only and log `#review-needed`.

These bands are enforced by `.cursor/rules/always/confidence-loops.mdc` and referenced in all pipeline rules.

## Backups

- **ensure_backup.max_age_minutes**: `1440` (24 hours)  
  Pipelines may call `obsidian_ensure_backup(path, max_age_minutes)` before long runs; only call `obsidian_create_backup` when needed.
- **BACKUP_DIR**: set in `~/.cursor/mcp.json` for the `obsidian-para-zettel-autopilot` server.  
  Recommended: a sibling folder such as `Second-Brain-Starter-Kit-Backups/` outside the vault.

## Snapshots

- **SNAPSHOT_DIR**: `<VAULT_ROOT>/Backups/Per-Change`
- **BATCH_SNAPSHOT_DIR**: `<VAULT_ROOT>/Backups/Batch`
- **SNAPSHOT_MAX_DAYS** (guideline): `30`
- **SNAPSHOT_MAX_PER_NOTE** (guideline): `100`

Retention is applied manually via the `snapshot-sweep` rule (`SNAPSHOT SWEEP` trigger), not automatically.

## Archive defaults

- **archive.age_days**: `90`
- **archive.no_activity_days**: `60`

Used by the `archive-check` skill to decide archive readiness (alongside status and open tasks).

## Highlightr defaults

- **highlighterStyle**: `realistic`
- **highlighterMethods**: `inline-styles`
- **master key**: `3-Resources/Highlightr-Color-Key.md`

Pipelines such as `distill-highlight-color` use `highlight_key` from frontmatter where present; otherwise they fall back to the master key above.

## Dry-run enforcement

- All calls to `obsidian_move_note` in pipelines must:
  - Run a `dry_run: true` preview first.
  - Only commit (`dry_run: false`) after reviewing effects and ensuring confidence ≥85% and snapshot success.

This is encoded in:

- `.cursor/rules/always/mcp-obsidian-integration.mdc`
- `.cursor/rules/context/para-zettel-autopilot.mdc`
- `.cursor/rules/context/auto-organize.mdc`
- `.cursor/rules/context/auto-archive.mdc`

## How to customize safely

- Prefer editing **this note** and `Second-Brain-Config.md` before touching rules/skills.
- When you change a value here:
  - Re-read `Cursor-Skill-Pipelines-Reference.md` to ensure your change is compatible.
  - Test on a small batch (e.g. a single project folder) before wide runs.

