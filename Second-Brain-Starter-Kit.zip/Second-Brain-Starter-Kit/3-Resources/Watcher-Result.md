---
title: Watcher Results
created: 2026-02-26
para-type: Resource
status: active
tags: [watcher, automation]
---

# Watcher Results

The `watcher-result-append.mdc` rule appends a single line here when a Watcher-triggered run finishes:

`requestId: <id> | status: success|failure | message: "..." | trace: "..."`

The Watcher plugin parses these lines to display completion notifications.

