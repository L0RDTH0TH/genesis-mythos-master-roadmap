---
title: Ingest Log
created: 2026-02-26
para-type: Resource
status: active
tags: [log, ingest, pipelines]
---

# Ingest Log

Pipeline log for **full-autonomous-ingest** runs.

Each line is appended by the automation pipeline after processing a note. See `Cursor-Skill-Pipelines-Reference.md` for the expected log format.

