---
title: Distill Log
created: 2026-02-26
para-type: Resource
status: active
tags: [log, distill, pipelines]
---

# Distill Log

Pipeline log for **autonomous-distill** runs.

Each entry should capture timestamp, note path, `distill_conf`, actions taken/skipped, snapshot paths, and any loop-related fields.

