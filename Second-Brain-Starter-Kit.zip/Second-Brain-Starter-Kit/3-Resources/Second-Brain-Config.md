---
title: Second Brain Config
created: 2026-02-26
tags: [pkm, second-brain, config]
para-type: Resource
status: active
links: [[Resources Hub]]
---

# Second Brain Config

Single source of truth for pipeline and skill configuration in the starter kit vault. Skills and rules that need hub names or thresholds should read this note (e.g. via context or Dataview).

## hub_names

- projects: "Projects Hub"
- areas: "Areas Hub"
- resources: "Resources Hub"
- resurface: "Resurface"

## archive

- age_days: 90
- no_activity_days: 60

## highlight

- default_key: "3-Resources/Highlightr-Color-Key.md"

## graph

- moc_strength: 3

**links frontmatter:** Always an array (e.g. `links: ["[[Resources Hub]]", "[[Related]]"]`). For Dataview, use `contains(links, "[[HubName]]")` or array membership.

**Tags vs frontmatter:** Tags are convenience only (e.g. #dev-task, #bug for QuickAdd and task filters). Pipelines and core filtering use frontmatter. Do not rely on tags for ingest/distill/archive logic.

Pipelines pass this note as context or read it when resolving hub names and archive thresholds. See `[3-Resources/Cursor-Skill-Pipelines-Reference.md](3-Resources/Cursor-Skill-Pipelines-Reference.md)` for pipeline order.

