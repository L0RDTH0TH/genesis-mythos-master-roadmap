Second-Brain Starter Kit – 3-Resources
======================================

This folder holds **evergreen reference material** for the starter kit:

- System configuration (`Second-Brain-Config.md`, `Config-Defaults.md`).
- Pipeline and automation references.
- Highlightr color keys and backup/snapshot guidance.
- Log notes (Ingest, Organize, Distill, Express, Archive, Backup, Errors).

The starter kit will populate this folder with the minimal set of docs needed
for autonomous ingest, organize, distill, express, and archive pipelines.

