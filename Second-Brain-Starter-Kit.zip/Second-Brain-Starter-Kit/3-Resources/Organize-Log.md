---
title: Organize Log
created: 2026-02-26
para-type: Resource
status: active
tags: [log, organize, pipelines]
---

# Organize Log

Pipeline log for **autonomous-organize** runs.

Entries document re-classification, path proposals, renames, moves (with dry_run previews), snapshots, and organize-path loop details.

