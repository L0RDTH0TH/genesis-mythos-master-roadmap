---
title: Watcher Signals
created: 2026-02-26
para-type: Resource
status: active
tags: [watcher, automation]
---

# Watcher Signals

Lines appended here by the Obsidian Watcher plugin indicate automation requests (e.g. INGEST MODE, DISTILL MODE).

The `watcher-result-append.mdc` rule and related pipelines read the last line to determine `requestId` and mode.

