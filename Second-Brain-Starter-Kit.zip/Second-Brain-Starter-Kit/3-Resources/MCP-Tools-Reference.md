---
title: MCP Tools Reference (Starter Kit)
created: 2026-02-26
para-type: Resource
status: active
tags: [mcp, tools, reference]
links: [[Resources Hub]]
---

# MCP Tools Reference — Starter Kit

This note lists the **most important MCP tools** used by the starter kit pipelines. For exact JSON schemas, refer to the tool descriptors under your Cursor MCP config (e.g. `~/.cursor/projects/.../mcps/user-obsidian-para-zettel-autopilot/tools/*.json`).

## Core note operations

| Tool | Key params (summary) | Notes / example |
|------|----------------------|-----------------|
| `obsidian_read_note` | `path` | Read full markdown content + frontmatter for a note. Used almost everywhere. |
| `obsidian_update_note` | `path`, `content`, `mode` (`overwrite` \| `append` \| `create`) | Write/update a note. Pipelines always ensure backup + snapshot before destructive overwrites. `mode: "create"` is used by `version-snapshot` to create new files without dest backup. |
| `obsidian_move_note` | `path`, `new_path`, `dry_run` (bool) | Move a note. Pipelines **must** call with `dry_run: true` first, inspect effects, then call with `dry_run: false` if safe. |
| `obsidian_rename_note` | `path`, `new_name` | Rename a note in place. Only used when confidence ≥85% and after per-change snapshot. |
| `obsidian_list_notes` | `folder` | List notes under a folder (e.g. `"Ingest"`). Used in ingest bootstrap and project discovery. |

## Backup and snapshots

| Tool | Key params | Notes |
|------|-----------|-------|
| `obsidian_create_backup` | `path` | Write an external-style backup into `BACKUP_DIR`. Called at the start of pipelines. |
| `obsidian_ensure_backup` | `path`, `max_age_minutes` | Check whether a recent backup exists; only call `obsidian_create_backup` when needed. |
| `obsidian_ensure_structure` | `folder_path` | Ensure a folder path (and parents) exist; used before deep moves and before writing snapshots/version files. |
| `health_check` | *(none or simple options)* | Returns basic server status and metrics; log to `MCP-Health-YYYY-MM.md` or `Backup-Log.md`. |

Snapshots are orchestrated by the `obsidian-snapshot` skill rather than direct tool calls.

## Classification and confidence

| Tool | Key params | Notes |
|------|-----------|-------|
| `obsidian_classify_para` | `path`, options | Classify a note into PARA type + themes. |
| `calibrate_confidence` | `prior_output`, context | Refine a mid-band decision using extra evidence; used in ingest/organize/archive/express loops. |
| `verify_classification` | `note_path`, `candidate` | Sanity-check a classification/path before moves. |
| `propose_alternative_paths` | `note_path`, `para_context`, `max_candidates` | Suggest alternative target paths when a move fails or is risky. |

## Path and organization

| Tool | Key params | Notes |
|------|-----------|-------|
| `obsidian_subfolder_organize` | `path`, `para_type`, `max_candidates` | MCP helper to propose target paths and scores; complements the `subfolder-organize` skill. |
| `obsidian_list_projects` | *(none or simple filters)* | Enumerate existing projects; used by ingest bootstrap. |
| `bootstrap_project_batch` | `paths`, `existing_projects_json` | Suggest new projects to create based on Ingest notes. |
| `confirm_bootstrap` | `decision` | Apply a bootstrap decision (e.g. create project folders). |

## Related content and MOCs

| Tool | Key params | Notes |
|------|-----------|-------|
| `obsidian_global_search` | `query` | Search note content by query (e.g. for related-content-pull, resurface). |
| `obsidian_suggest_connections` | `note_path`, `num_suggestions`, `auto_insert`, `suggested_links` | Server-side semantic related-notes helper; can auto-insert a Related section (wrap in `[!related]` callout). |
| `obsidian_append_to_moc` | `source_path`, `moc_path`, `section`, `line` | Append a link to a Map-of-Content (MOC) note. |
| `obsidian_generate_moc` | `topic`, `moc_path`, `tag_or_folder`, `content` | Generate a new MOC note for a topic/folder. |

## Tasks and garden flows (optional extensions)

These tools are **not wired** into the starter kit by default but are useful if you extend the pipelines:

| Tool | Purpose |
|------|---------|
| `find_parent` | Locate a likely parent Area/Project for tasks. |
| `obsidian_create_task_note` | Create a dedicated task note under a parent path. |
| `append_tasks` | Append tasks to an existing task/hub note. |
| `obsidian_garden_review` | Produce a report of orphans, distill candidates, weak links. |
| `obsidian_curate_cluster` | Suggest gaps, merges, and synthesis for a cluster (e.g. tagged notes). |
| `obsidian_refactor_to_zettel` | Refactor a literature/fleeting note into atomic zettels. |

Use `Automation-Flows-MCP-Improvements.md` and your main vault docs for ideas about when and how to introduce these tools.

