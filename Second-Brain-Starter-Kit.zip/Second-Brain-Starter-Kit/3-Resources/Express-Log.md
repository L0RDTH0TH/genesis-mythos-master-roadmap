---
title: Express Log
created: 2026-02-26
para-type: Resource
status: active
tags: [log, express, pipelines]
---

# Express Log

Pipeline log for **autonomous-express** runs.

Entries track related-content, outlines, CTAs, version-snapshot paths, per-change snapshots, and any soft-loop behavior.

