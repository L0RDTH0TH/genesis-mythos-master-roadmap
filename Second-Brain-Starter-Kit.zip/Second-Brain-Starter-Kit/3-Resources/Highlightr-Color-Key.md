---
title: Highlightr Color Key
created: 2026-02-26
tags: [pkm, second-brain, distill, highlightr]
para-type: Resource
status: active
links: [[Resources Hub]]
---

# Highlightr Color Key – Starter Kit

## 1. Semantic Mapping

| Color  | Intended meaning                                      |
|--------|-------------------------------------------------------|
| Yellow | Key facts, premises, supporting evidence, main points |
| Green  | Definitions, explanations of terms, core concepts     |
| Blue   | Actionable items, instructions, next steps, thesis statements |
| Red    | Disagreements, critiques, warnings, questions, high-priority review |
| Orange | Examples, case studies, applications, analogies       |
| Purple | Quotes (direct verbatim), key insights, mental models/frameworks |
| Pink   | Ideas to resurface later, connections to other notes, open questions |
| Cyan   | Secondary/supporting details, less critical but useful |
| Grey   | Deprecated, outdated, or low-confidence info          |

## 2. Highlightr Plugin Storage Format (Required)

The starter kit assumes Highlightr is configured for **inline CSS** storage.

**Inline CSS format (must be used by pipelines):**

- Yellow: `<mark style="background: #FFF3A3A6;">text</mark>`
- Green:  `<mark style="background: #C1E1C1A6;">text</mark>`
- Blue:   `<mark style="background: #A3D8FFA6;">text</mark>`
- Red:    `<mark style="background: #FFAAAAA6;">text</mark>`
- Orange: `<mark style="background: #FFD9A3A6;">text</mark>`
- Purple: `<mark style="background: #E6CCFFA6;">text</mark>`
- Pink:   `<mark style="background: #FFC1CCA6;">text</mark>`
- Cyan:   `<mark style="background: #A3FFFFA6;">text</mark>`
- Grey:   `<mark style="background: #E0E0E0A6;">text</mark>`

**Rules:**

- Native Obsidian `==text==` is **not** used by the pipelines for semantic highlights.
- Do not append `^{Color}` or other superscript/footnote syntax for new highlights.
- Use a single storage format per note (do not mix).

## 3. Project-Specific Guidelines (Examples)

Skills (e.g. `distill-highlight-color`, `layer-promote`) use frontmatter **`highlight_key`** for project overrides; if absent, they fall back to the master key above.

Examples:

- **Generic projects**: Use analogous colors (e.g. blue–green) for related ideas across notes; use complementary colors (e.g. blue vs orange) for contrasting or conflicting ideas so relations are clear.
- **Audits / reviews**: Consider using more Red/Orange for critiques, open questions, and review items; keep Yellow/Green for stable facts and definitions.

For more detail on how pipelines use this key, see `[3-Resources/Cursor-Skill-Pipelines-Reference.md](3-Resources/Cursor-Skill-Pipelines-Reference.md)` and the `distill-highlight-color` SKILL.

